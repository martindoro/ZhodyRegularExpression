package valid_ip_regular_expression;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IpValidator {
	public static void validator(String ipAddress) {
		Pattern pattern = Pattern.compile(
				"((2[0-5][0-5])|([0-1]?[\\d]?[\\d]?))\\.((2[0-5][0-5])|([0-1]?[\\d]?[\\d]?))\\.((2[0-5][0-5])|([\\d]?[\\d]?[\\d]?))\\.((2[0-5][0-5])|([0-1]?[\\d]?[\\d]?))");
		Matcher matcher = pattern.matcher(ipAddress);
		if (matcher.matches()) {
			System.out.println("IP adresa (" + ipAddress + ") JE validná.");
		} else {
			System.out.println("IP adresa (" + ipAddress + ") NIE JE validná.");
		}
	}
}
